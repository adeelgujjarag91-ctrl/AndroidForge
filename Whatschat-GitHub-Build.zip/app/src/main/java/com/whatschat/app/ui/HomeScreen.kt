package com.whatschat.app.ui

import android.provider.CallLog
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.whatschat.app.*

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(vm: MainViewModel, nav: Nav) {
    val wa = LocalWA.current
    val ctx = LocalContext.current
    StatusBar(wa.bar)
    val chats by vm.chats.collectAsState()
    val prefs by vm.settings.collectAsState()
    val cm by vm.contactMap.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    var query by rememberSaveable { mutableStateOf("") }
    var filter by rememberSaveable { mutableIntStateOf(0) }
    var menu by remember { mutableStateOf(false) }
    var selMenu by remember { mutableStateOf(false) }
    val selected = remember { mutableStateListOf<String>() }
    var confirmDelete by remember { mutableStateOf(false) }
    var statusDialog by remember { mutableStateOf(false) }
    var calls by remember { mutableStateOf<List<CallItem>>(emptyList()) }
    val call = rememberCaller()
    val (isDefault, requestDefault) = rememberDefaultSms()
    var bannerHidden by rememberSaveable { mutableStateOf(false) }
    val searchFocus = remember { FocusRequester() }
    val photo = remember { loadProfile(ctx) }

    LaunchedEffect(tab) { calls = vm.loadCalls() }
    BackHandler(selected.isNotEmpty()) { selected.clear() }

    val unreadTotal = chats.count { it.unread > 0 || it.thread.markedUnread }
    val missed = calls.count { it.type == CallLog.Calls.MISSED_TYPE }
    val sel = chats.filter { it.thread.threadKey in selected }

    Scaffold(
        containerColor = wa.bg,
        topBar = {
            if (selected.isNotEmpty()) {
                Surface(color = wa.bar) {
                    Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton({ selected.clear() }) { Icon(Icons.Filled.Close, null, tint = wa.barText) }
                        Text("${selected.size}", color = wa.barText, fontSize = 20.sp, modifier = Modifier.weight(1f))
                        val pinAll = sel.isNotEmpty() && sel.all { it.thread.pinned }
                        IconButton({ vm.updateThreads(selected.toList()) { it.copy(pinned = !pinAll) }; selected.clear() }) {
                            Icon(Icons.Filled.PushPin, "Pin chat", tint = wa.barText)
                        }
                        val muteAll = sel.isNotEmpty() && sel.all { it.thread.muted }
                        IconButton({ vm.updateThreads(selected.toList()) { it.copy(muted = !muteAll) }; selected.clear() }) {
                            Icon(Icons.Filled.NotificationsOff, "Mute notifications", tint = wa.barText)
                        }
                        IconButton({ confirmDelete = true }) { Icon(Icons.Filled.Delete, "Delete chat", tint = wa.barText) }
                        Box {
                            IconButton({ selMenu = true }) { Icon(Icons.Filled.MoreVert, null, tint = wa.barText) }
                            DropdownMenu(selMenu, { selMenu = false }) {
                                DropdownMenuItem(text = { Text("Mark as unread") }, onClick = {
                                    selMenu = false
                                    vm.updateThreads(selected.toList()) { it.copy(markedUnread = true) }; selected.clear()
                                })
                                val favAll = sel.isNotEmpty() && sel.all { it.thread.favorite }
                                DropdownMenuItem(
                                    text = { Text(if (favAll) "Remove from favorites" else "Add to favorites") },
                                    onClick = {
                                        selMenu = false
                                        vm.updateThreads(selected.toList()) { it.copy(favorite = !favAll) }; selected.clear()
                                    })
                            }
                        }
                    }
                }
            } else {
                Surface(color = wa.bar) {
                    Row(
                        Modifier.fillMaxWidth().height(64.dp).padding(start = 16.dp, end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            when (tab) { 0 -> "Whatschat"; 1 -> "Updates"; else -> "Calls" },
                            color = wa.brand, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)
                        )
                        IconButton({
                            Toast.makeText(ctx, "Photos need MMS/internet. Whatschat is SMS-only.", Toast.LENGTH_SHORT).show()
                        }) { Icon(Icons.Filled.CameraAlt, "Camera", tint = wa.barText) }
                        IconButton({ tab = 0; runCatching { searchFocus.requestFocus() } }) {
                            Icon(Icons.Filled.Search, "Search", tint = wa.barText)
                        }
                        Box {
                            IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "More", tint = wa.barText) }
                            DropdownMenu(menu, { menu = false }) {
                                DropdownMenuItem(text = { Text("New broadcast") }, onClick = { menu = false; nav.push(Screen.Broadcast) })
                                DropdownMenuItem(text = { Text("Starred messages") }, onClick = { menu = false; nav.push(Screen.Starred) })
                                DropdownMenuItem(text = { Text("Settings") }, onClick = { menu = false; nav.push(Screen.Settings) })
                            }
                        }
                    }
                }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = wa.bar) {
                val items = listOf(
                    Triple("Chats", Icons.AutoMirrored.Filled.Chat, unreadTotal),
                    Triple("Updates", Icons.Filled.DonutLarge, 0),
                    Triple("Calls", Icons.Filled.Call, missed)
                )
                items.forEachIndexed { i, (label, icon, badge) ->
                    NavigationBarItem(
                        selected = tab == i, onClick = { tab = i },
                        icon = {
                            BadgedBox(badge = { if (badge > 0) Badge(containerColor = wa.accent, contentColor = wa.onAccent) { Text("$badge") } }) {
                                Icon(icon, label)
                            }
                        },
                        label = { Text(label, fontWeight = if (tab == i) FontWeight.Bold else FontWeight.Normal) },
                        colors = NavigationBarItemDefaults.colors(
                            indicatorColor = wa.pill, selectedIconColor = wa.barText, selectedTextColor = wa.barText,
                            unselectedIconColor = wa.sub, unselectedTextColor = wa.sub
                        )
                    )
                }
            }
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    when (tab) {
                        0 -> nav.push(Screen.Select(Mode.CHAT))
                        1 -> statusDialog = true
                        else -> nav.push(Screen.Select(Mode.CALL))
                    }
                },
                containerColor = wa.accent, contentColor = if (wa.dark) wa.onAccent else Color.White,
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(
                    when (tab) { 0 -> Icons.AutoMirrored.Filled.Chat; 1 -> Icons.Filled.Edit; else -> Icons.Filled.Call },
                    null
                )
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> {
                    val rows = chats.filter { r ->
                        (query.isBlank() || r.name.contains(query, true) || r.thread.address.contains(query) ||
                            r.last.body.contains(query, true)) &&
                            when (filter) {
                                1 -> r.unread > 0 || r.thread.markedUnread
                                2 -> r.thread.favorite
                                3 -> r.thread.isGroup
                                else -> true
                            }
                    }
                    LazyColumn(Modifier.fillMaxSize()) {
                        if (!isDefault && !bannerHidden) item {
                            Surface(
                                Modifier.fillMaxWidth().padding(12.dp), shape = RoundedCornerShape(12.dp), color = wa.pill
                            ) {
                                Column(Modifier.padding(14.dp)) {
                                    Text("Receive SMS in Whatschat", fontWeight = FontWeight.Bold, color = wa.text)
                                    Text(
                                        "Make Whatschat your default SMS app so incoming messages arrive here.",
                                        color = wa.sub, fontSize = 14.sp
                                    )
                                    Row {
                                        TextButton(requestDefault) { Text("Set as default") }
                                        TextButton({ bannerHidden = true }) { Text("Not now") }
                                    }
                                }
                            }
                        }
                        item {
                            TextField(
                                value = query, onValueChange = { query = it }, singleLine = true,
                                placeholder = { Text("Search") },
                                leadingIcon = { Icon(Icons.Filled.Search, null) },
                                shape = RoundedCornerShape(28.dp),
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = wa.field, unfocusedContainerColor = wa.field,
                                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                                    focusedTextColor = wa.text, unfocusedTextColor = wa.text
                                ),
                                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp)
                                    .focusRequester(searchFocus)
                            )
                        }
                        item {
                            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(listOf("All", "Unread", "Favorites", "Groups").withIndex().toList()) { (i, label) ->
                                    FilterChip(
                                        selected = filter == i, onClick = { filter = i }, label = { Text(label) },
                                        shape = RoundedCornerShape(20.dp),
                                        colors = FilterChipDefaults.filterChipColors(
                                            selectedContainerColor = wa.pill, selectedLabelColor = wa.text
                                        )
                                    )
                                }
                            }
                        }
                        if (rows.isEmpty()) item {
                            Text(
                                if (chats.isEmpty()) "No chats yet.\nTap the green button to start a chat."
                                else "No chats match.",
                                color = wa.sub, modifier = Modifier.fillMaxWidth().padding(48.dp),
                                fontSize = 15.sp, lineHeight = 22.sp
                            )
                        }
                        items(rows, key = { it.thread.threadKey }) { r ->
                            val isSel = r.thread.threadKey in selected
                            ChatListItem(
                                r, isSel,
                                onClick = {
                                    if (selected.isNotEmpty()) { if (isSel) selected.remove(r.thread.threadKey) else selected.add(r.thread.threadKey) }
                                    else nav.push(Screen.Chat(r.thread.threadKey))
                                },
                                onLong = { if (isSel) selected.remove(r.thread.threadKey) else selected.add(r.thread.threadKey) }
                            )
                        }
                    }
                }
                1 -> LazyColumn(Modifier.fillMaxSize()) {
                    item {
                        Text("Status", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = wa.text, modifier = Modifier.padding(16.dp))
                        Row(
                            Modifier.fillMaxWidth().clickable { statusDialog = true }.padding(horizontal = 16.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Avatar(prefs.name.ifBlank { "Me" }, 52.dp, photo)
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text("My status", fontWeight = FontWeight.Medium, fontSize = 17.sp, color = wa.text)
                                Text(prefs.status.ifBlank { "Tap to add a status update" }, color = wa.sub, fontSize = 14.sp)
                            }
                        }
                        Text(
                            "Status notes are stored on this device. Whatschat works fully offline over your SIM's SMS and voice calls.",
                            color = wa.sub, fontSize = 13.sp, modifier = Modifier.padding(16.dp), lineHeight = 19.sp
                        )
                    }
                }
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    if (calls.isEmpty()) item {
                        Text(
                            "No calls yet.\nTap the call button to call a contact over your SIM.",
                            color = wa.sub, modifier = Modifier.fillMaxWidth().padding(48.dp), fontSize = 15.sp, lineHeight = 22.sp
                        )
                    }
                    items(calls.size) { idx ->
                        val c = calls[idx]
                        val name = cm[PhoneUtil.key(c.number)]?.name ?: c.number
                        val isMissed = c.type == CallLog.Calls.MISSED_TYPE
                        Row(
                            Modifier.fillMaxWidth().clickable { call(c.number) }.padding(horizontal = 16.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Avatar(name, 52.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(name, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = if (isMissed) Color(0xFFEA0038) else wa.text, maxLines = 1)
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        when (c.type) {
                                            CallLog.Calls.OUTGOING_TYPE -> Icons.AutoMirrored.Filled.CallMade
                                            CallLog.Calls.MISSED_TYPE -> Icons.AutoMirrored.Filled.CallMissed
                                            else -> Icons.AutoMirrored.Filled.CallReceived
                                        }, null, Modifier.size(16.dp),
                                        tint = if (isMissed) Color(0xFFEA0038) else wa.accent
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Text("${dayLabel(c.ts)}, ${fmtTime(c.ts)}", color = wa.sub, fontSize = 14.sp)
                                }
                            }
                            Icon(Icons.Filled.Call, "Call", tint = wa.brand.takeIf { !wa.dark } ?: wa.accent)
                        }
                    }
                }
            }
        }
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false },
        title = { Text("Delete ${selected.size} chat(s)?") },
        text = { Text("Messages in these chats will be removed from this device.") },
        confirmButton = { TextButton({ vm.deleteChats(selected.toList()); selected.clear(); confirmDelete = false }) { Text("Delete chat") } },
        dismissButton = { TextButton({ confirmDelete = false }) { Text("Cancel") } }
    )
    if (statusDialog) TextDialog("My status", prefs.status, onDismiss = { statusDialog = false }) { s ->
        vm.updateSettings { it.copy(status = s) }; statusDialog = false
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatListItem(r: ChatRow, selected: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val wa = LocalWA.current
    val unread = r.unread > 0 || r.thread.markedUnread
    Row(
        Modifier.fillMaxWidth().background(if (selected) wa.pill else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box {
            Avatar(r.name, 52.dp)
            if (selected) Box(
                Modifier.align(Alignment.BottomEnd).size(20.dp).clip(CircleShape).background(wa.accent),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.Done, null, Modifier.size(14.dp), tint = Color.White) }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(r.name, maxLines = 1, overflow = TextOverflow.Ellipsis, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = wa.text)
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (r.last.outgoing) { Ticks(r.last.status); Spacer(Modifier.width(3.dp)) }
                Text(r.last.body.replace("\n", " "), maxLines = 1, overflow = TextOverflow.Ellipsis, color = wa.sub, fontSize = 14.sp)
            }
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(fmtListTime(r.last.timestamp), fontSize = 12.sp, color = if (unread) wa.accent else wa.sub)
            Spacer(Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (r.thread.muted) Icon(Icons.Filled.NotificationsOff, null, Modifier.size(16.dp), tint = wa.sub)
                if (r.thread.pinned) Icon(Icons.Filled.PushPin, null, Modifier.size(16.dp), tint = wa.sub)
                if (r.unread > 0) {
                    Spacer(Modifier.width(4.dp))
                    Box(
                        Modifier.defaultMinSize(minWidth = 20.dp).height(20.dp).clip(CircleShape).background(wa.accent).padding(horizontal = 6.dp),
                        contentAlignment = Alignment.Center
                    ) { Text("${r.unread}", color = wa.onAccent, fontSize = 12.sp, fontWeight = FontWeight.Bold) }
                } else if (r.thread.markedUnread) {
                    Spacer(Modifier.width(4.dp))
                    Box(Modifier.size(12.dp).clip(CircleShape).background(wa.accent))
                }
            }
        }
    }
}
