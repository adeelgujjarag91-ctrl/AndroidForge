package com.whatschat.app

import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telephony.SmsManager
import android.telephony.SmsMessage
import android.telephony.SubscriptionManager
import java.util.concurrent.atomic.AtomicInteger

/** Sends SMS directly through the chosen SIM. Never opens any external SMS app. */
object SmsSender {
    const val SENT = "com.whatschat.app.SMS_SENT"
    const val DELIVERED = "com.whatschat.app.SMS_DELIVERED"
    private val counter = AtomicInteger((System.currentTimeMillis() % 100000).toInt())

    fun subId(ctx: Context, slot: Int): Int? = try {
        ctx.getSystemService(SubscriptionManager::class.java)
            .activeSubscriptionInfoList?.firstOrNull { it.simSlotIndex == slot }?.subscriptionId
    } catch (_: SecurityException) {
        null
    }

    fun simNames(ctx: Context): List<String> = try {
        ctx.getSystemService(SubscriptionManager::class.java).activeSubscriptionInfoList
            ?.sortedBy { it.simSlotIndex }
            ?.map { "SIM ${it.simSlotIndex + 1} • ${it.carrierName}" } ?: emptyList()
    } catch (_: SecurityException) {
        emptyList()
    }

    @Suppress("DEPRECATION")
    fun manager(ctx: Context, slot: Int): SmsManager {
        val id = subId(ctx, slot)
        return if (Build.VERSION.SDK_INT >= 31) {
            val base = ctx.getSystemService(SmsManager::class.java)
            if (id != null) base.createForSubscriptionId(id) else base
        } else {
            if (id != null) SmsManager.getSmsManagerForSubscriptionId(id) else SmsManager.getDefault()
        }
    }

    fun segments(text: String): Int = if (text.isEmpty()) 0 else SmsMessage.calculateLength(text, false)[0]

    private fun pi(ctx: Context, action: String, id: Long, part: Int, total: Int): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, counter.incrementAndGet(),
            Intent(action).setPackage(ctx.packageName)
                .putExtra("id", id).putExtra("part", part).putExtra("total", total),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun send(ctx: Context, id: Long, to: String, body: String, slot: Int, reports: Boolean) {
        val sm = manager(ctx, slot)
        val parts = sm.divideMessage(body)
        val sent = ArrayList<PendingIntent>()
        val delivered = ArrayList<PendingIntent>()
        for (i in 0 until parts.size) {
            sent.add(pi(ctx, SENT, id, i, parts.size))
            if (reports) delivered.add(pi(ctx, DELIVERED, id, i, parts.size))
        }
        sm.sendMultipartTextMessage(to, null, parts, sent, if (reports) delivered else null)
    }
}
