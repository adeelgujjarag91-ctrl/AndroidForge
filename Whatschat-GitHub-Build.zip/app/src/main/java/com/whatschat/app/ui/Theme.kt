package com.whatschat.app.ui

import android.app.Activity
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.unit.Density
import androidx.core.view.WindowCompat
import com.whatschat.app.Prefs

@Immutable
data class WA(
    val dark: Boolean, val bar: Color, val barText: Color, val brand: Color, val chatHeader: Color,
    val bg: Color, val inBubble: Color, val outBubble: Color, val text: Color, val sub: Color,
    val wallpaper: Color, val accent: Color, val onAccent: Color, val divider: Color,
    val field: Color, val composer: Color, val pill: Color
)

val LightWalls = listOf(0xFFEFEAE2, 0xFFE3EEDD, 0xFFDDE8F3, 0xFFF3E4DC, 0xFFEDEDED)
val DarkWalls = listOf(0xFF0B141A, 0xFF0D1B17, 0xFF0F1923, 0xFF1B1511, 0xFF000000)

fun lightWA(wall: Color) = WA(
    false, Color.White, Color(0xFF111B21), Color(0xFF008069), Color(0xFF008069),
    Color.White, Color.White, Color(0xFFD9FDD3), Color(0xFF111B21), Color(0xFF667781),
    wall, Color(0xFF25D366), Color.White, Color(0xFFE9EDEF),
    Color(0xFFF0F2F5), Color.White, Color(0xFFD9FDD3)
)

fun darkWA(wall: Color) = WA(
    true, Color(0xFF111B21), Color(0xFFE9EDEF), Color(0xFF25D366), Color(0xFF202C33),
    Color(0xFF0B141A), Color(0xFF202C33), Color(0xFF005C4B), Color(0xFFE9EDEF), Color(0xFF8696A0),
    wall, Color(0xFF00A884), Color(0xFF0B141A), Color(0xFF222D34),
    Color(0xFF202C33), Color(0xFF202C33), Color(0xFF103629)
)

val LocalWA = staticCompositionLocalOf { lightWA(Color(0xFFEFEAE2)) }

@Composable
fun WhatschatTheme(prefs: Prefs, content: @Composable () -> Unit) {
    val dark = when (prefs.theme) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val walls = if (dark) DarkWalls else LightWalls
    val wall = Color(walls[prefs.wallpaper.coerceIn(0, walls.lastIndex)])
    val wa = if (dark) darkWA(wall) else lightWA(wall)
    val scheme = if (dark) darkColorScheme(
        primary = wa.accent, onPrimary = wa.onAccent, background = wa.bg, surface = wa.bg,
        onSurface = wa.text, onBackground = wa.text, surfaceVariant = wa.field,
        onSurfaceVariant = wa.sub, secondaryContainer = wa.pill, onSecondaryContainer = wa.text,
        surfaceContainer = wa.composer, surfaceContainerHigh = wa.composer
    ) else lightColorScheme(
        primary = Color(0xFF008069), onPrimary = Color.White, background = wa.bg, surface = wa.bg,
        onSurface = wa.text, onBackground = wa.text, surfaceVariant = wa.field,
        onSurfaceVariant = wa.sub, secondaryContainer = wa.pill, onSecondaryContainer = wa.text,
        surfaceContainer = Color.White, surfaceContainerHigh = Color.White
    )
    val d = LocalDensity.current
    CompositionLocalProvider(
        LocalWA provides wa,
        LocalDensity provides Density(d.density, d.fontScale * prefs.fontScale)
    ) { MaterialTheme(colorScheme = scheme, content = content) }
}

@Composable
fun StatusBar(color: Color) {
    val view = LocalView.current
    SideEffect {
        val w = (view.context as Activity).window
        w.statusBarColor = color.toArgb()
        WindowCompat.getInsetsController(w, view).isAppearanceLightStatusBars = color.luminance() > 0.5f
    }
}
