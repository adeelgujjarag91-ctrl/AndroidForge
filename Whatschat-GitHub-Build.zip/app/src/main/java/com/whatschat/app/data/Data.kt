package com.whatschat.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

/** status: -1 failed, 0 sending, 1 sent, 2 delivered, 4 received */
@Entity(tableName = "messages", indices = [Index("threadKey")])
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val threadKey: String,
    val address: String,
    val body: String,
    val timestamp: Long,
    val outgoing: Boolean,
    val status: Int,
    val starred: Boolean = false,
    val replyPreview: String? = null,
    val simSlot: Int = 0,
    val read: Boolean = true,
    val parts: Int = 1
)

@Entity(tableName = "threads")
data class ThreadEntity(
    @PrimaryKey val threadKey: String,
    val address: String,
    val title: String? = null,
    val pinned: Boolean = false,
    val muted: Boolean = false,
    val favorite: Boolean = false,
    val markedUnread: Boolean = false,
    val isGroup: Boolean = false,
    val blocked: Boolean = false
)

@Dao
interface MessageDao {
    @Insert suspend fun insert(m: MessageEntity): Long
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(m: List<MessageEntity>)
    @Query("SELECT * FROM messages WHERE threadKey=:k ORDER BY timestamp ASC, id ASC")
    fun observeThread(k: String): Flow<List<MessageEntity>>
    @Query("SELECT * FROM messages ORDER BY timestamp DESC, id DESC")
    fun observeAll(): Flow<List<MessageEntity>>
    @Query("SELECT * FROM messages WHERE starred=1 ORDER BY timestamp DESC")
    fun observeStarred(): Flow<List<MessageEntity>>
    @Query("SELECT * FROM messages") suspend fun all(): List<MessageEntity>
    @Query("UPDATE messages SET status=:s WHERE id=:id AND status>=0 AND status<:s")
    suspend fun raise(id: Long, s: Int)
    @Query("UPDATE messages SET status=-1 WHERE id=:id") suspend fun setFailed(id: Long)
    @Query("UPDATE messages SET read=1 WHERE threadKey=:k AND read=0") suspend fun markRead(k: String)
    @Query("UPDATE messages SET starred=:s WHERE id IN (:ids)") suspend fun setStarred(ids: List<Long>, s: Boolean)
    @Query("DELETE FROM messages WHERE id IN (:ids)") suspend fun deleteIds(ids: List<Long>)
    @Query("DELETE FROM messages WHERE threadKey=:k") suspend fun deleteThread(k: String)
}

@Dao
interface ThreadDao {
    @Query("SELECT * FROM threads") fun observeAll(): Flow<List<ThreadEntity>>
    @Query("SELECT * FROM threads WHERE threadKey=:k") fun observe(k: String): Flow<ThreadEntity?>
    @Query("SELECT * FROM threads WHERE threadKey=:k") suspend fun get(k: String): ThreadEntity?
    @Query("SELECT * FROM threads") suspend fun all(): List<ThreadEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(t: ThreadEntity)
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(t: List<ThreadEntity>)
    @Query("DELETE FROM threads WHERE threadKey=:k") suspend fun delete(k: String)
}

@Database(entities = [MessageEntity::class, ThreadEntity::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun messages(): MessageDao
    abstract fun threads(): ThreadDao

    companion object {
        @Volatile private var inst: AppDatabase? = null
        fun get(ctx: Context): AppDatabase = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDatabase::class.java, "whatschat.db")
                .build().also { inst = it }
        }
    }
}
