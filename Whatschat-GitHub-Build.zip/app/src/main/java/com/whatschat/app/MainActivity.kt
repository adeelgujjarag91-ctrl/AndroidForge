package com.whatschat.app

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.whatschat.app.ui.*

sealed interface Screen {
    object Home : Screen
    data class Select(val mode: Mode, val forwardText: String = "") : Screen
    data class NewContact(val prefill: String = "") : Screen
    data class Chat(val key: String, val draft: String = "") : Screen
    object Settings : Screen
    object Starred : Screen
    object Broadcast : Screen
}

enum class Mode { CHAT, CALL, FORWARD }

class Nav(val push: (Screen) -> Unit, val pop: () -> Unit, val replace: (Screen) -> Unit)

data class Pending(val key: String? = null, val address: String? = null, val draft: String = "")

class MainActivity : ComponentActivity() {
    private val vm by viewModels<MainViewModel>()
    private val pending = mutableStateOf<Pending?>(null)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        handle(intent)
        setContent {
            val prefs by vm.settings.collectAsState()
            WhatschatTheme(prefs) { AppRoot(vm, pending.value) { pending.value = null } }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handle(intent)
    }

    override fun onResume() {
        super.onResume()
        vm.refreshContacts()
    }

    private fun handle(i: Intent?) {
        i ?: return
        i.getStringExtra("threadKey")?.let { pending.value = Pending(key = it); return }
        val d = i.data ?: return
        if (d.scheme in listOf("sms", "smsto", "mms", "mmsto")) {
            val num = Uri.decode(d.schemeSpecificPart.substringBefore('?')).trim()
            val body = i.getStringExtra("sms_body") ?: i.getStringExtra(Intent.EXTRA_TEXT) ?: ""
            if (num.isNotBlank()) pending.value = Pending(address = num, draft = body)
        }
    }
}

@Composable
fun AppRoot(vm: MainViewModel, pending: Pending?, handled: () -> Unit) {
    val ctx = LocalContext.current
    val stack = remember { mutableStateListOf<Screen>(Screen.Home) }
    val nav = remember {
        Nav(
            push = { stack.add(it) },
            pop = { if (stack.size > 1) stack.removeAt(stack.lastIndex) },
            replace = { stack.removeAt(stack.lastIndex); stack.add(it) }
        )
    }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        vm.refreshContacts()
    }
    LaunchedEffect(Unit) {
        val perms = mutableListOf(
            Manifest.permission.SEND_SMS, Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS,
            Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CONTACTS,
            Manifest.permission.WRITE_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CALL_LOG
        )
        if (Build.VERSION.SDK_INT >= 33) perms.add(Manifest.permission.POST_NOTIFICATIONS)
        val need = perms.filter { ctx.checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (need.isNotEmpty()) permLauncher.launch(need.toTypedArray())
    }
    LaunchedEffect(pending) {
        pending?.let { p ->
            val key = p.key ?: vm.ensure(p.address!!).threadKey
            stack.add(Screen.Chat(key, p.draft))
            handled()
        }
    }
    BackHandler(stack.size > 1) { nav.pop() }

    when (val s = stack.last()) {
        Screen.Home -> HomeScreen(vm, nav)
        is Screen.Select -> SelectContactScreen(vm, s.mode, s.forwardText, nav)
        is Screen.NewContact -> NewContactScreen(vm, s.prefill, nav)
        is Screen.Chat -> ChatScreen(vm, s.key, s.draft, nav)
        Screen.Settings -> SettingsScreen(vm, nav)
        Screen.Starred -> StarredScreen(vm, nav)
        Screen.Broadcast -> BroadcastScreen(vm, nav)
    }
}
