package com.whatschat.app

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import com.whatschat.app.data.AppDatabase
import com.whatschat.app.data.MessageEntity
import com.whatschat.app.data.ThreadEntity
import org.json.JSONArray
import org.json.JSONObject

class WhatschatApp : Application() {
    lateinit var db: AppDatabase
    lateinit var settings: SettingsManager
    lateinit var contacts: ContactsManager
    lateinit var repo: Repo

    override fun onCreate() {
        super.onCreate()
        db = AppDatabase.get(this)
        settings = SettingsManager(this)
        contacts = ContactsManager(this)
        repo = Repo(this)
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel("messages", "Messages", NotificationManager.IMPORTANCE_HIGH)
            )
        }
    }
}

val Context.wapp: WhatschatApp get() = applicationContext as WhatschatApp

class Repo(private val app: WhatschatApp) {
    private val db get() = app.db

    suspend fun ensureThread(
        address: String, title: String? = null, isGroup: Boolean = false,
        key: String = PhoneUtil.key(address)
    ): ThreadEntity {
        db.threads().get(key)?.let { return it }
        val t = ThreadEntity(key, address, title, isGroup = isGroup)
        db.threads().upsert(t)
        return t
    }

    suspend fun send(thread: ThreadEntity, body: String, replyPreview: String? = null) {
        val s = app.settings.state.value
        val addrs = if (thread.isGroup) thread.address.split(",").map { it.trim() } else listOf(thread.address)
        val parts = SmsSender.segments(body).coerceAtLeast(1)
        val id = db.messages().insert(
            MessageEntity(
                threadKey = thread.threadKey, address = thread.address, body = body,
                timestamp = System.currentTimeMillis(), outgoing = true, status = 0,
                replyPreview = replyPreview, simSlot = s.defaultSlot, parts = parts
            )
        )
        try {
            addrs.forEach { SmsSender.send(app, id, it, body, s.defaultSlot, s.deliveryReports) }
            app.settings.addUsed(parts * addrs.size)
        } catch (e: Exception) {
            db.messages().setFailed(id)
        }
    }

    suspend fun onIncoming(address: String, body: String, ts: Long, slot: Int) {
        val t = ensureThread(address)
        if (t.blocked) return
        db.messages().insert(
            MessageEntity(
                threadKey = t.threadKey, address = address, body = body, timestamp = ts,
                outgoing = false, status = 4, read = false, simSlot = slot
            )
        )
        val name = t.title ?: app.contacts.nameFor(address) ?: address
        Notifier.show(app, t, name, body)
    }

    suspend fun exportJson(): String {
        val root = JSONObject().put("version", 1)
        val ms = JSONArray()
        db.messages().all().forEach { m ->
            ms.put(
                JSONObject().put("id", m.id).put("threadKey", m.threadKey).put("address", m.address)
                    .put("body", m.body).put("timestamp", m.timestamp).put("outgoing", m.outgoing)
                    .put("status", m.status).put("starred", m.starred)
                    .put("replyPreview", m.replyPreview ?: JSONObject.NULL)
                    .put("simSlot", m.simSlot).put("read", m.read).put("parts", m.parts)
            )
        }
        val ts = JSONArray()
        db.threads().all().forEach { t ->
            ts.put(
                JSONObject().put("threadKey", t.threadKey).put("address", t.address)
                    .put("title", t.title ?: JSONObject.NULL).put("pinned", t.pinned).put("muted", t.muted)
                    .put("favorite", t.favorite).put("markedUnread", t.markedUnread)
                    .put("isGroup", t.isGroup).put("blocked", t.blocked)
            )
        }
        return root.put("messages", ms).put("threads", ts).toString(2)
    }

    suspend fun importJson(s: String) {
        val root = JSONObject(s)
        val ts = root.getJSONArray("threads")
        db.threads().upsertAll((0 until ts.length()).map {
            val o = ts.getJSONObject(it)
            ThreadEntity(
                o.getString("threadKey"), o.getString("address"),
                if (o.isNull("title")) null else o.getString("title"),
                o.optBoolean("pinned"), o.optBoolean("muted"), o.optBoolean("favorite"),
                o.optBoolean("markedUnread"), o.optBoolean("isGroup"), o.optBoolean("blocked")
            )
        })
        val ms = root.getJSONArray("messages")
        db.messages().insertAll((0 until ms.length()).map {
            val o = ms.getJSONObject(it)
            MessageEntity(
                o.getLong("id"), o.getString("threadKey"), o.getString("address"), o.getString("body"),
                o.getLong("timestamp"), o.getBoolean("outgoing"), o.getInt("status"), o.optBoolean("starred"),
                if (o.isNull("replyPreview")) null else o.getString("replyPreview"),
                o.optInt("simSlot"), o.optBoolean("read", true), o.optInt("parts", 1)
            )
        })
    }
}

object Notifier {
    fun show(app: WhatschatApp, t: ThreadEntity, name: String, body: String) {
        if (!app.settings.state.value.notifications || t.muted) return
        if (Build.VERSION.SDK_INT >= 33 &&
            app.checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val i = Intent(app, MainActivity::class.java).putExtra("threadKey", t.threadKey)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val pi = PendingIntent.getActivity(
            app, t.threadKey.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(app, "messages")
            .setSmallIcon(R.drawable.ic_notification).setContentTitle(name).setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setColor(0xFF008069.toInt()).setAutoCancel(true).setContentIntent(pi)
            .setCategory(NotificationCompat.CATEGORY_MESSAGE).build()
        app.getSystemService(NotificationManager::class.java).notify(t.threadKey.hashCode(), n)
    }
}
