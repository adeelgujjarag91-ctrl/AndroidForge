package com.whatschat.app.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.whatschat.app.*
import com.whatschat.app.data.MessageEntity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

private val EMOJIS = ("😀 😃 😄 😁 😆 😅 😂 🤣 😊 😇 🙂 😉 😍 🥰 😘 😋 😎 🤩 🥳 😏 😒 😞 😔 😟 😕 🙁 😣 😖 😫 😩 🥺 😢 😭 😤 😠 😡 🤯 😳 " +
    "😱 😰 🤗 🤔 🤭 🤫 😶 😐 😑 😬 🙄 😴 👍 👎 👏 🙌 🙏 💪 👋 ✌ ❤ 🧡 💛 💚 💙 💜 🖤 💔 🔥 ✨ 🎉 🎂 🎁 🌹 ☀ 🌙 ⭐").split(" ")

private val TEMPLATES = listOf(
    "I'll call you back", "On my way", "Please call me", "Thank you!", "Running late, will be there soon"
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ChatScreen(vm: MainViewModel, key: String, draft: String, nav: Nav) {
    val wa = LocalWA.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val clip = LocalClipboardManager.current
    val kb = LocalSoftwareKeyboardController.current
    val threadFlow = remember(key) { vm.thread(key) }
    val msgFlow = remember(key) { vm.messages(key) }
    val thread by threadFlow.collectAsState(initial = null)
    val msgs by msgFlow.collectAsState(initial = emptyList())
    val cm by vm.contactMap.collectAsState()
    val prefs by vm.settings.collectAsState()
    val contacts by vm.contacts.collectAsState()
    val call = rememberCaller()
    val listState = rememberLazyListState()

    var input by remember { mutableStateOf(draft) }
    var emojiOpen by remember { mutableStateOf(false) }
    var replyTo by remember { mutableStateOf<MessageEntity?>(null) }
    val selected = remember { mutableStateListOf<Long>() }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf(false) }
    var attach by remember { mutableStateOf(false) }
    var dialog by remember { mutableStateOf("") } // templates | contacts | view | clear | delete
    val locPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) insertLocation(ctx) { input = if (input.isBlank()) it else input + "\n" + it }
    }

    LaunchedEffect(msgs.size) { if (msgs.isNotEmpty()) listState.scrollToItem(msgs.lastIndex) }
    LaunchedEffect(key, msgs.size) { vm.markRead(key) }
    BackHandler(selected.isNotEmpty() || searching || emojiOpen) {
        when {
            selected.isNotEmpty() -> selected.clear()
            emojiOpen -> emojiOpen = false
            else -> { searching = false; query = "" }
        }
    }

    val t = thread
    if (t == null) { Box(Modifier.fillMaxSize().background(wa.bg)); return }

    val contact = cm[t.threadKey]
    val name = t.title ?: contact?.name ?: t.address
    val unsaved = contact == null && !t.isGroup
    val simLabel = "SIM ${prefs.defaultSlot + 1} • Offline SMS"
    val shown = if (query.isBlank()) msgs else msgs.filter { it.body.contains(query, true) }
    val selMsgs = msgs.filter { it.id in selected }
    val hdr = wa.chatHeader
    val onHdr = if (wa.dark) wa.text else Color.White

    fun send() {
        val text = input.trim()
        if (text.isEmpty()) return
        val preview = replyTo?.let { "${if (it.outgoing) "You" else name}: ${it.body.take(80)}" }
        vm.send(t, text, preview)
        input = ""; replyTo = null
    }

    Column(Modifier.fillMaxSize().background(wa.bg)) {
        // ---- Header / contextual action bar ----
        if (selected.isNotEmpty()) {
            StatusBar(hdr)
            Surface(color = hdr) {
                Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ selected.clear() }) { Icon(Icons.Filled.Close, null, tint = onHdr) }
                    Text("${selected.size}", color = onHdr, fontSize = 20.sp, modifier = Modifier.weight(1f))
                    if (selected.size == 1) IconButton({ replyTo = selMsgs.firstOrNull(); selected.clear() }) {
                        Icon(Icons.AutoMirrored.Filled.Reply, "Reply", tint = onHdr)
                    }
                    val allStar = selMsgs.isNotEmpty() && selMsgs.all { it.starred }
                    IconButton({ vm.star(selected.toList(), !allStar); selected.clear() }) {
                        Icon(if (allStar) Icons.Filled.StarBorder else Icons.Filled.Star, "Star", tint = onHdr)
                    }
                    IconButton({
                        clip.setText(AnnotatedString(selMsgs.joinToString("\n") { it.body }))
                        Toast.makeText(ctx, "Copied", Toast.LENGTH_SHORT).show(); selected.clear()
                    }) { Icon(Icons.Filled.ContentCopy, "Copy", tint = onHdr) }
                    IconButton({
                        val text = selMsgs.joinToString("\n") { it.body }
                        selected.clear()
                        nav.push(Screen.Select(Mode.FORWARD, text))
                    }) { Icon(Icons.AutoMirrored.Filled.ArrowForward, "Forward", tint = onHdr) }
                    IconButton({ dialog = "delete" }) { Icon(Icons.Filled.Delete, "Delete", tint = onHdr) }
                }
            }
        } else if (searching) {
            StatusBar(hdr)
            Surface(color = hdr) {
                Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ searching = false; query = "" }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = onHdr) }
                    TextField(
                        query, { query = it }, singleLine = true, placeholder = { Text("Search…", color = onHdr.copy(alpha = .6f)) },
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = onHdr, unfocusedTextColor = onHdr, cursorColor = onHdr
                        ), modifier = Modifier.weight(1f)
                    )
                }
            }
        } else {
            StatusBar(hdr)
            Surface(color = hdr) {
                Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ nav.pop() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = onHdr) }
                    Avatar(name, 38.dp)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f).clickable { dialog = "view" }) {
                        Text(name, color = onHdr, fontSize = 18.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            if (t.isGroup) "${t.address.split(",").size} recipients • $simLabel" else simLabel,
                            color = onHdr.copy(alpha = .75f), fontSize = 12.sp
                        )
                    }
                    if (!t.isGroup) IconButton({ call(t.address) }) { Icon(Icons.Filled.Call, "SIM voice call", tint = onHdr) }
                    Box {
                        IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, null, tint = onHdr) }
                        DropdownMenu(menu, { menu = false }) {
                            DropdownMenuItem(text = { Text("View contact") }, onClick = { menu = false; dialog = "view" })
                            DropdownMenuItem(text = { Text("Search") }, onClick = { menu = false; searching = true })
                            DropdownMenuItem(text = { Text("Clear chat") }, onClick = { menu = false; dialog = "clear" })
                            DropdownMenuItem(text = { Text("Export chat") }, onClick = {
                                menu = false
                                val txt = msgs.joinToString("\n") {
                                    "${SimpleDateFormat("dd/MM/yyyy, h:mm a", Locale.getDefault()).format(Date(it.timestamp))} - " +
                                        "${if (it.outgoing) "You" else name}: ${it.body}"
                                }
                                ctx.startActivity(Intent.createChooser(
                                    Intent(Intent.ACTION_SEND).setType("text/plain")
                                        .putExtra(Intent.EXTRA_SUBJECT, "Whatschat chat with $name").putExtra(Intent.EXTRA_TEXT, txt),
                                    "Export chat"
                                ))
                            })
                        }
                    }
                }
            }
        }

        // ---- Unsaved number action bar ----
        if (unsaved && !t.blocked) Surface(color = wa.bg, tonalElevation = 2.dp) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton({ nav.push(Screen.NewContact(t.address)) }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.PersonAdd, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Add to contacts")
                }
                TextButton({ vm.updateThreads(listOf(key)) { it.copy(blocked = true) } }, modifier = Modifier.weight(1f)) {
                    Icon(Icons.Filled.Block, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("Block")
                }
            }
        }

        // ---- Messages on wallpaper ----
        Box(Modifier.weight(1f).fillMaxWidth().background(wa.wallpaper).drawBehind {
            val c = (if (wa.dark) Color.White else Color.Black).copy(alpha = 0.035f)
            var y = 18f
            while (y < size.height) {
                var x = if (((y / 60f).toInt() % 2) == 0) 18f else 48f
                while (x < size.width) { drawCircle(c, 3f, Offset(x, y)); x += 60f }
                y += 60f
            }
        }) {
            LazyColumn(state = listState, contentPadding = PaddingValues(vertical = 8.dp), modifier = Modifier.fillMaxSize()) {
                itemsIndexed(shown, key = { _, m -> m.id }) { i, m ->
                    val prev = shown.getOrNull(i - 1)
                    if (prev == null || dayLabel(prev.timestamp) != dayLabel(m.timestamp)) {
                        Box(Modifier.fillMaxWidth().padding(vertical = 6.dp), contentAlignment = Alignment.Center) {
                            Text(
                                dayLabel(m.timestamp), fontSize = 12.sp, color = wa.sub,
                                modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(wa.bar.copy(alpha = .9f)).padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }
                    val isSel = m.id in selected
                    MessageRow(
                        m, tail = prev == null || prev.outgoing != m.outgoing || dayLabel(prev.timestamp) != dayLabel(m.timestamp),
                        selected = isSel,
                        onClick = {
                            if (selected.isNotEmpty()) { if (isSel) selected.remove(m.id) else selected.add(m.id) }
                            else if (m.status == -1) {
                                vm.deleteMessages(listOf(m.id)); vm.send(t, m.body, m.replyPreview)
                                Toast.makeText(ctx, "Retrying…", Toast.LENGTH_SHORT).show()
                            }
                        },
                        onLong = { if (isSel) selected.remove(m.id) else selected.add(m.id) }
                    )
                }
            }
        }

        // ---- Composer ----
        if (t.blocked) {
            Surface(color = wa.bar) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("You blocked this number.", color = wa.sub, modifier = Modifier.weight(1f).padding(start = 8.dp))
                    TextButton({ vm.updateThreads(listOf(key)) { it.copy(blocked = false) } }) { Text("Unblock") }
                }
            }
        } else {
            Column(Modifier.background(wa.wallpaper)) {
                replyTo?.let { r ->
                    Row(
                        Modifier.fillMaxWidth().padding(horizontal = 8.dp).clip(RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp))
                            .background(wa.composer).padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.width(4.dp).height(36.dp).background(wa.accent))
                        Column(Modifier.weight(1f).padding(horizontal = 8.dp)) {
                            Text(if (r.outgoing) "You" else name, color = wa.accent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(r.body, color = wa.sub, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        IconButton({ replyTo = null }, Modifier.size(28.dp)) { Icon(Icons.Filled.Close, null, tint = wa.sub) }
                    }
                }
                if (input.isNotEmpty()) Text(
                    "${input.length} chars / ${SmsSender.segments(input)} SMS", fontSize = 11.sp, color = wa.sub,
                    modifier = Modifier.align(Alignment.End).padding(end = 70.dp)
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp), verticalAlignment = Alignment.Bottom) {
                    Surface(shape = RoundedCornerShape(26.dp), color = wa.composer, modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.Bottom) {
                            IconButton({ emojiOpen = !emojiOpen; if (emojiOpen) kb?.hide() else kb?.show() }) {
                                Icon(if (emojiOpen) Icons.Filled.Keyboard else Icons.Filled.EmojiEmotions, "Emoji", tint = wa.sub)
                            }
                            TextField(
                                input, { input = it }, placeholder = { Text("Message") }, maxLines = 5,
                                colors = TextFieldDefaults.colors(
                                    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                                    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                                    focusedTextColor = wa.text, unfocusedTextColor = wa.text, cursorColor = wa.accent
                                ), modifier = Modifier.weight(1f)
                            )
                            Box {
                                IconButton({ attach = true }) { Icon(Icons.Filled.AttachFile, "Attach", tint = wa.sub) }
                                DropdownMenu(attach, { attach = false }) {
                                    DropdownMenuItem(text = { Text("Contact") }, leadingIcon = { Icon(Icons.Filled.Person, null) },
                                        onClick = { attach = false; dialog = "contacts" })
                                    DropdownMenuItem(text = { Text("Location") }, leadingIcon = { Icon(Icons.Filled.LocationOn, null) },
                                        onClick = {
                                            attach = false
                                            if (ctx.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
                                                insertLocation(ctx) { input = if (input.isBlank()) it else input + "\n" + it }
                                            else locPerm.launch(Manifest.permission.ACCESS_FINE_LOCATION)
                                        })
                                    DropdownMenuItem(text = { Text("Quick SMS template") }, leadingIcon = { Icon(Icons.Filled.Sms, null) },
                                        onClick = { attach = false; dialog = "templates" })
                                }
                            }
                        }
                    }
                    Spacer(Modifier.width(6.dp))
                    Box(
                        Modifier.size(50.dp).clip(CircleShape).background(wa.accent).clickable {
                            if (input.isBlank()) Toast.makeText(ctx, "Voice notes need MMS/internet. Whatschat is SMS-only.", Toast.LENGTH_SHORT).show()
                            else send()
                        }, contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (input.isBlank()) Icons.Filled.Mic else Icons.AutoMirrored.Filled.Send,
                            if (input.isBlank()) "Mic" else "Send", tint = if (wa.dark) wa.onAccent else Color.White
                        )
                    }
                }
                if (emojiOpen) Surface(color = wa.composer) {
                    LazyVerticalGrid(GridCells.Fixed(8), Modifier.fillMaxWidth().height(230.dp)) {
                        items(EMOJIS) { e ->
                            Text(e, fontSize = 26.sp, modifier = Modifier.clickable { input += e }.padding(6.dp))
                        }
                    }
                }
            }
        }
    }

    // ---- Dialogs ----
    when (dialog) {
        "templates" -> AlertDialog(
            onDismissRequest = { dialog = "" }, title = { Text("Quick SMS template") },
            text = {
                Column {
                    TEMPLATES.forEach { tpl ->
                        Text(tpl, Modifier.fillMaxWidth().clickable { input = tpl; dialog = "" }.padding(vertical = 12.dp), color = wa.text)
                    }
                }
            }, confirmButton = { TextButton({ dialog = "" }) { Text("Close") } }
        )
        "contacts" -> AlertDialog(
            onDismissRequest = { dialog = "" }, title = { Text("Share contact") },
            text = {
                if (contacts.isEmpty()) Text("No contacts found.")
                else LazyColumn(Modifier.heightIn(max = 360.dp)) {
                    items(contacts.size) { i ->
                        val c = contacts[i]
                        Column(Modifier.fillMaxWidth().clickable {
                            input = if (input.isBlank()) "${c.name}: ${c.number}" else "$input\n${c.name}: ${c.number}"; dialog = ""
                        }.padding(vertical = 8.dp)) {
                            Text(c.name, color = wa.text); Text(c.number, color = wa.sub, fontSize = 13.sp)
                        }
                    }
                }
            }, confirmButton = { TextButton({ dialog = "" }) { Text("Close") } }
        )
        "view" -> AlertDialog(
            onDismissRequest = { dialog = "" }, title = { Text(name) },
            text = {
                Column {
                    Text(if (t.isGroup) t.address.split(",").joinToString("\n") else t.address, color = wa.text)
                    Text(if (unsaved) "Not in your contacts" else "Saved contact", color = wa.sub, fontSize = 13.sp)
                    Text(simLabel, color = wa.sub, fontSize = 13.sp)
                }
            },
            confirmButton = {
                if (unsaved) TextButton({ dialog = ""; nav.push(Screen.NewContact(t.address)) }) { Text("Add to contacts") }
                else TextButton({ dialog = "" }) { Text("Close") }
            },
            dismissButton = { if (!t.isGroup) TextButton({ dialog = ""; call(t.address) }) { Text("Call") } }
        )
        "clear" -> AlertDialog(
            onDismissRequest = { dialog = "" }, title = { Text("Clear this chat?") },
            text = { Text("All messages in this chat will be removed from this device.") },
            confirmButton = { TextButton({ vm.clearChat(key); dialog = "" }) { Text("Clear chat") } },
            dismissButton = { TextButton({ dialog = "" }) { Text("Cancel") } }
        )
        "delete" -> AlertDialog(
            onDismissRequest = { dialog = "" }, title = { Text("Delete message?") },
            confirmButton = { TextButton({ vm.deleteMessages(selected.toList()); selected.clear(); dialog = "" }) { Text("Delete") } },
            dismissButton = { TextButton({ dialog = "" }) { Text("Cancel") } }
        )
    }
}

@SuppressWarnings("MissingPermission")
private fun insertLocation(ctx: Context, onText: (String) -> Unit) {
    try {
        val lm = ctx.getSystemService(LocationManager::class.java)
        val loc = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER, LocationManager.PASSIVE_PROVIDER)
            .mapNotNull { runCatching { lm.getLastKnownLocation(it) }.getOrNull() }
            .maxByOrNull { it.time }
        if (loc == null) Toast.makeText(ctx, "Location unavailable. Turn on GPS and try again.", Toast.LENGTH_SHORT).show()
        else onText("My location: https://maps.google.com/?q=${loc.latitude},${loc.longitude}")
    } catch (e: SecurityException) {
        Toast.makeText(ctx, "Location permission needed", Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MessageRow(m: MessageEntity, tail: Boolean, selected: Boolean, onClick: () -> Unit, onLong: () -> Unit) {
    val wa = LocalWA.current
    Box(
        Modifier.fillMaxWidth().background(if (selected) wa.accent.copy(alpha = .25f) else Color.Transparent)
            .combinedClickable(onClick = onClick, onLongClick = onLong)
            .padding(horizontal = 8.dp, vertical = 1.dp)
    ) {
        Box(
            Modifier.align(if (m.outgoing) Alignment.CenterEnd else Alignment.CenterStart).widthIn(max = 300.dp)
                .background(if (m.outgoing) wa.outBubble else wa.inBubble, BubbleShape(m.outgoing, tail))
                .padding(
                    start = if (m.outgoing) 8.dp else 16.dp, end = if (m.outgoing) 16.dp else 8.dp,
                    top = 5.dp, bottom = 4.dp
                )
        ) {
            Column {
                if (m.replyPreview != null) Row(
                    Modifier.padding(bottom = 4.dp).clip(RoundedCornerShape(6.dp)).background(Color.Black.copy(alpha = .08f)).height(IntrinsicSize.Min)
                ) {
                    Box(Modifier.width(4.dp).fillMaxHeight().background(wa.accent))
                    Text(m.replyPreview, Modifier.padding(6.dp), color = wa.sub, fontSize = 13.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
                }
                Box {
                    Text(m.body + "\u00A0".repeat(if (m.outgoing) 14 else 11), color = wa.text, fontSize = 16.sp)
                    Row(Modifier.align(Alignment.BottomEnd), verticalAlignment = Alignment.CenterVertically) {
                        if (m.starred) { Icon(Icons.Filled.Star, null, Modifier.size(12.dp), tint = wa.sub); Spacer(Modifier.width(2.dp)) }
                        Text(fmtTime(m.timestamp), color = wa.sub, fontSize = 11.sp)
                        if (m.outgoing) { Spacer(Modifier.width(3.dp)); Ticks(m.status) }
                    }
                }
            }
        }
    }
}
