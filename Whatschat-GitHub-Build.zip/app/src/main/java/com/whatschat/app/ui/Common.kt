package com.whatschat.app.ui

import android.annotation.SuppressLint
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Telephony
import android.telecom.TelecomManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.whatschat.app.wapp
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

fun fmtTime(ts: Long): String = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(ts))

private fun sameDay(a: Calendar, b: Calendar) =
    a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)

fun dayLabel(ts: Long): String {
    val now = Calendar.getInstance()
    val c = Calendar.getInstance().apply { timeInMillis = ts }
    val y = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1) }
    return when {
        sameDay(c, now) -> "Today"
        sameDay(c, y) -> "Yesterday"
        else -> SimpleDateFormat("d MMMM yyyy", Locale.getDefault()).format(Date(ts))
    }
}

fun fmtListTime(ts: Long): String = when (val d = dayLabel(ts)) {
    "Today" -> fmtTime(ts)
    "Yesterday" -> d
    else -> SimpleDateFormat("dd/MM/yy", Locale.getDefault()).format(Date(ts))
}

fun loadProfile(ctx: Context): ImageBitmap? {
    val f = File(ctx.filesDir, "profile.jpg")
    if (!f.exists()) return null
    return try {
        BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = 2 })?.asImageBitmap()
    } catch (_: Exception) {
        null
    }
}

@Composable
fun Avatar(name: String, size: Dp = 48.dp, photo: ImageBitmap? = null) {
    val colors = listOf(0xFF6A7175, 0xFF1F7AEC, 0xFFD6336C, 0xFF9C27B0, 0xFFE67E22, 0xFF00897B, 0xFF5C6BC0, 0xFF8D6E63)
    val unsaved = name.firstOrNull()?.let { it.isDigit() || it == '+' } ?: true
    val bg = if (unsaved) Color(0xFFB0BEC5) else Color(colors[(name.hashCode() and 0x7fffffff) % colors.size])
    Box(Modifier.size(size).clip(CircleShape).background(bg), contentAlignment = Alignment.Center) {
        when {
            photo != null -> Image(photo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            unsaved -> Icon(Icons.Filled.Person, null, Modifier.size(size * 0.6f), tint = Color.White)
            else -> Text(name.first().uppercase(), color = Color.White, fontSize = (size.value * 0.42f).sp)
        }
    }
}

@Composable
fun Ticks(status: Int, size: Dp = 16.dp) {
    val wa = LocalWA.current
    when (status) {
        0 -> Icon(Icons.Filled.Schedule, null, Modifier.size(size - 3.dp), tint = wa.sub)
        1 -> Icon(Icons.Filled.Done, null, Modifier.size(size), tint = wa.sub)
        2 -> Icon(Icons.Filled.DoneAll, null, Modifier.size(size), tint = wa.sub)
        -1 -> Icon(Icons.Filled.ErrorOutline, null, Modifier.size(size), tint = Color(0xFFEA0038))
    }
}

/** WhatsApp-style bubble: rounded rectangle with a small tail on the top outer corner. */
class BubbleShape(private val outgoing: Boolean, private val tail: Boolean) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val t = with(density) { 8.dp.toPx() }
        val r = with(density) { 8.dp.toPx() }
        val left = if (outgoing) 0f else t
        val right = if (outgoing) size.width - t else size.width
        val cr = CornerRadius(r)
        val sq = CornerRadius.Zero
        val rect = RoundRect(
            left, 0f, right, size.height,
            topLeftCornerRadius = if (!outgoing && tail) sq else cr,
            topRightCornerRadius = if (outgoing && tail) sq else cr,
            bottomRightCornerRadius = cr, bottomLeftCornerRadius = cr
        )
        val p = Path().apply {
            addRoundRect(rect)
            if (tail) {
                if (outgoing) { moveTo(right, 0f); lineTo(size.width, 0f); lineTo(right, t * 1.2f); close() }
                else { moveTo(left, 0f); lineTo(0f, 0f); lineTo(left, t * 1.2f); close() }
            }
        }
        return Outline.Generic(p)
    }
}

@Composable
fun SimpleTopBar(
    title: String, subtitle: String? = null, onBack: () -> Unit,
    color: Color = LocalWA.current.bar, content: Color = LocalWA.current.barText,
    actions: @Composable RowScope.() -> Unit = {}
) {
    StatusBar(color)
    Surface(color = color) {
        Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null, tint = content) }
            Column(Modifier.weight(1f)) {
                Text(title, color = content, fontSize = 19.sp, fontWeight = FontWeight.Medium)
                if (subtitle != null) Text(subtitle, color = content.copy(alpha = .75f), fontSize = 13.sp)
            }
            actions()
        }
    }
}

@Composable
fun TextDialog(title: String, initial: String, number: Boolean = false, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            OutlinedTextField(
                v, { v = it }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = if (number) KeyboardType.Number else KeyboardType.Text)
            )
        },
        confirmButton = { TextButton({ onSave(v.trim()) }) { Text("Save") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

@SuppressLint("MissingPermission")
fun placeCall(ctx: Context, number: String) {
    val tm = ctx.getSystemService(TelecomManager::class.java)
    val slot = ctx.wapp.settings.state.value.defaultSlot
    val extras = Bundle()
    try {
        val accts = tm.callCapablePhoneAccounts
        if (accts.size > 1 && accts.size > slot) extras.putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, accts[slot])
    } catch (_: SecurityException) {
    }
    try {
        tm.placeCall(Uri.fromParts("tel", number, null), extras)
    } catch (e: SecurityException) {
        Toast.makeText(ctx, "Call permission needed", Toast.LENGTH_SHORT).show()
    }
}

/** Returns a function that places a SIM call directly (asking for CALL_PHONE first if needed). */
@Composable
fun rememberCaller(): (String) -> Unit {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<String?>(null) }
    val l = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        val n = pending
        pending = null
        if (ok && n != null) placeCall(ctx, n)
    }
    return { number ->
        if (ctx.checkSelfPermission(android.Manifest.permission.CALL_PHONE) == android.content.pm.PackageManager.PERMISSION_GRANTED)
            placeCall(ctx, number)
        else { pending = number; l.launch(android.Manifest.permission.CALL_PHONE) }
    }
}

/** (isDefaultSmsApp, requestDefault) */
@Composable
fun rememberDefaultSms(): Pair<Boolean, () -> Unit> {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    val l = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { tick++ }
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    DisposableEffect(lifecycle) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        lifecycle.addObserver(o)
        onDispose { lifecycle.removeObserver(o) }
    }
    val isDef = remember(tick) { Telephony.Sms.getDefaultSmsPackage(ctx) == ctx.packageName }
    val request: () -> Unit = {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val rm = ctx.getSystemService(RoleManager::class.java)
                if (rm.isRoleAvailable(RoleManager.ROLE_SMS)) l.launch(rm.createRequestRoleIntent(RoleManager.ROLE_SMS))
            } else {
                l.launch(
                    Intent(Telephony.Sms.Intents.ACTION_CHANGE_DEFAULT)
                        .putExtra(Telephony.Sms.Intents.EXTRA_PACKAGE_NAME, ctx.packageName)
                )
            }
        } catch (e: Exception) {
            Toast.makeText(ctx, "Cannot open default SMS app picker", Toast.LENGTH_SHORT).show()
        }
    }
    return Pair(isDef, request)
}
