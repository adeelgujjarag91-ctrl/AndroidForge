package com.whatschat.app

import android.app.Activity
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.IBinder
import android.provider.Telephony
import android.telephony.TelephonyManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** Receives real incoming SMS (SMS_DELIVER as default app; SMS_RECEIVED otherwise). */
class SmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val isDefault = Telephony.Sms.getDefaultSmsPackage(c) == c.packageName
        // When we are the default app both broadcasts fire; only handle SMS_DELIVER then.
        if (i.action == Telephony.Sms.Intents.SMS_RECEIVED_ACTION && isDefault) return
        val msgs = Telephony.Sms.Intents.getMessagesFromIntent(i) ?: return
        if (msgs.isEmpty()) return
        val ts = msgs.first().timestampMillis.takeIf { it > 0 } ?: System.currentTimeMillis()
        val slot = i.getIntExtra("slot", i.getIntExtra("android.telephony.extra.SLOT_INDEX", 0))
        val grouped = msgs.groupBy { it.displayOriginatingAddress ?: "" }
        val pr = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                grouped.forEach { (addr, list) ->
                    if (addr.isNotBlank())
                        c.wapp.repo.onIncoming(addr, list.joinToString("") { it.displayMessageBody ?: "" }, ts, slot)
                }
            } finally {
                pr.finish()
            }
        }
    }
}

/** Required for the default-SMS role. Whatschat is an SMS-only app, so MMS push is accepted and ignored. */
class MmsReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {}
}

/** Updates ticks: sent (single) -> delivered (double) or failed. */
class SmsStatusReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) {
        val id = i.getLongExtra("id", -1)
        if (id < 0) return
        val last = i.getIntExtra("part", 0) == i.getIntExtra("total", 1) - 1
        val ok = resultCode == Activity.RESULT_OK
        val pr = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = c.wapp.db.messages()
                if (i.action == SmsSender.SENT) {
                    if (!ok) dao.setFailed(id) else if (last) dao.raise(id, 1)
                } else if (last && ok) dao.raise(id, 2)
            } finally {
                pr.finish()
            }
        }
    }
}

/** Quick "respond via message" (e.g. decline a call with a text) while we are the default SMS app. */
class HeadlessSmsSendService : Service() {
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, flags: Int, startId: Int): Int {
        if (i?.action == TelephonyManager.ACTION_RESPOND_VIA_MESSAGE) {
            val to = i.data?.schemeSpecificPart?.substringBefore('?')?.trim()
            val text = i.getStringExtra(Intent.EXTRA_TEXT)
            if (!to.isNullOrBlank() && !text.isNullOrBlank()) {
                CoroutineScope(Dispatchers.IO).launch {
                    val t = wapp.repo.ensureThread(to)
                    wapp.repo.send(t, text)
                    stopSelf(startId)
                }
                return START_NOT_STICKY
            }
        }
        stopSelf(startId)
        return START_NOT_STICKY
    }
}
