package com.whatschat.app

import android.app.Application
import android.provider.CallLog
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.whatschat.app.data.MessageEntity
import com.whatschat.app.data.ThreadEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ChatRow(val thread: ThreadEntity, val name: String, val last: MessageEntity, val unread: Int)
data class CallItem(val number: String, val type: Int, val ts: Long)

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val a = app as WhatschatApp
    val settings: StateFlow<Prefs> = a.settings.state
    val contacts = MutableStateFlow<List<Contact>>(emptyList())
    val contactMap: StateFlow<Map<String, Contact>> =
        contacts.map { l -> l.associateBy { it.key } }.stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    val chats: StateFlow<List<ChatRow>> = combine(
        a.db.threads().observeAll(), a.db.messages().observeAll(), contactMap
    ) { ts, ms, cm ->
        val byKey = ms.groupBy { it.threadKey }
        ts.mapNotNull { t ->
            val l = byKey[t.threadKey] ?: return@mapNotNull null
            ChatRow(t, t.title ?: cm[t.threadKey]?.name ?: t.address, l.first(), l.count { !it.outgoing && !it.read })
        }.sortedWith(compareByDescending<ChatRow> { it.thread.pinned }.thenByDescending { it.last.timestamp })
    }.flowOn(Dispatchers.Default).stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val starred = a.db.messages().observeStarred().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    fun messages(key: String) = a.db.messages().observeThread(key)
    fun thread(key: String) = a.db.threads().observe(key)

    fun refreshContacts() {
        viewModelScope.launch(Dispatchers.IO) { contacts.value = a.contacts.list() }
    }

    suspend fun ensure(address: String) = withContext(Dispatchers.IO) { a.repo.ensureThread(address) }

    suspend fun createBroadcast(name: String, numbers: List<String>): ThreadEntity = withContext(Dispatchers.IO) {
        a.repo.ensureThread(numbers.joinToString(","), name, true, "bc_" + System.currentTimeMillis())
    }

    suspend fun saveContact(first: String, last: String, number: String): Boolean = withContext(Dispatchers.IO) {
        val ok = a.contacts.save(first, last, number)
        if (ok) contacts.value = a.contacts.list()
        ok
    }

    fun send(t: ThreadEntity, body: String, reply: String? = null) {
        viewModelScope.launch(Dispatchers.IO) { a.repo.send(t, body, reply) }
    }

    fun forward(number: String, body: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val t = a.repo.ensureThread(number)
            a.repo.send(t, body)
        }
    }

    fun markRead(key: String) {
        viewModelScope.launch(Dispatchers.IO) {
            a.db.messages().markRead(key)
            a.db.threads().get(key)?.let { if (it.markedUnread) a.db.threads().upsert(it.copy(markedUnread = false)) }
        }
    }

    fun updateThreads(keys: List<String>, f: (ThreadEntity) -> ThreadEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            keys.forEach { k -> a.db.threads().get(k)?.let { a.db.threads().upsert(f(it)) } }
        }
    }

    fun deleteChats(keys: List<String>) {
        viewModelScope.launch(Dispatchers.IO) {
            keys.forEach { a.db.messages().deleteThread(it); a.db.threads().delete(it) }
        }
    }

    fun clearChat(key: String) {
        viewModelScope.launch(Dispatchers.IO) { a.db.messages().deleteThread(key) }
    }

    fun star(ids: List<Long>, v: Boolean) {
        viewModelScope.launch(Dispatchers.IO) { a.db.messages().setStarred(ids, v) }
    }

    fun deleteMessages(ids: List<Long>) {
        viewModelScope.launch(Dispatchers.IO) { a.db.messages().deleteIds(ids) }
    }

    fun updateSettings(f: (Prefs) -> Prefs) = a.settings.update(f)

    suspend fun exportJson() = a.repo.exportJson()
    suspend fun importJson(s: String) = a.repo.importJson(s)

    /** Real call history from the device call log (includes calls placed from Whatschat). */
    suspend fun loadCalls(): List<CallItem> = withContext(Dispatchers.IO) {
        val ctx = getApplication<Application>()
        if (ctx.checkSelfPermission(android.Manifest.permission.READ_CALL_LOG) != android.content.pm.PackageManager.PERMISSION_GRANTED)
            return@withContext emptyList()
        val out = ArrayList<CallItem>()
        try {
            ctx.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                arrayOf(CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DATE),
                null, null, "${CallLog.Calls.DATE} DESC"
            )?.use { c ->
                while (c.moveToNext() && out.size < 200) {
                    val n = c.getString(0) ?: ""
                    if (n.isNotBlank()) out.add(CallItem(n, c.getInt(1), c.getLong(2)))
                }
            }
        } catch (_: Exception) {
        }
        out
    }
}
