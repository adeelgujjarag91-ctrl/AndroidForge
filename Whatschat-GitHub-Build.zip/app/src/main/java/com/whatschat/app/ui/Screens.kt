package com.whatschat.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.telephony.TelephonyManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.whatschat.app.*
import kotlinx.coroutines.launch

@Composable
private fun ActionRow(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, onClick: () -> Unit) {
    val wa = LocalWA.current
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(wa.accent), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = if (wa.dark) wa.onAccent else Color.White)
        }
        Spacer(Modifier.width(16.dp))
        Text(title, fontSize = 17.sp, fontWeight = FontWeight.Medium, color = wa.text)
    }
}

@Composable
fun SelectContactScreen(vm: MainViewModel, mode: Mode, forwardText: String, nav: Nav) {
    val wa = LocalWA.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val contacts by vm.contacts.collectAsState()
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    val call = rememberCaller()
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { vm.refreshContacts() }
    val hasPerm = ctx.checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED
    val filtered = contacts.filter { query.isBlank() || it.name.contains(query, true) || it.number.contains(query) }
    val typed = PhoneUtil.clean(query)

    fun pick(number: String) {
        when (mode) {
            Mode.CHAT -> scope.launch { val t = vm.ensure(number); nav.replace(Screen.Chat(t.threadKey)) }
            Mode.CALL -> { call(number); nav.pop() }
            Mode.FORWARD -> {
                vm.forward(number, forwardText)
                Toast.makeText(ctx, "Forwarded via SIM SMS", Toast.LENGTH_SHORT).show()
                nav.pop()
            }
        }
    }

    Column(Modifier.fillMaxSize().background(wa.bg)) {
        if (searching) {
            StatusBar(wa.bar)
            Surface(color = wa.bar) {
                Row(Modifier.fillMaxWidth().height(64.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton({ searching = false; query = "" }) { Icon(Icons.Filled.Close, null, tint = wa.barText) }
                    TextField(
                        query, { query = it }, singleLine = true, placeholder = { Text("Search name or number") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                        colors = TextFieldDefaults.colors(
                            focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
                            focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
                            focusedTextColor = wa.text, unfocusedTextColor = wa.text
                        ), modifier = Modifier.weight(1f)
                    )
                }
            }
        } else {
            SimpleTopBar(
                when (mode) { Mode.CHAT -> "Select contact"; Mode.CALL -> "Select contact to call"; Mode.FORWARD -> "Forward to…" },
                "${contacts.size} contacts", onBack = { nav.pop() }
            ) {
                IconButton({ searching = true }) { Icon(Icons.Filled.Search, null, tint = wa.barText) }
            }
        }
        LazyColumn(Modifier.fillMaxSize()) {
            if (mode == Mode.CHAT && !searching) {
                item { ActionRow(Icons.Filled.PersonAdd, "New contact") { nav.push(Screen.NewContact()) } }
                item { ActionRow(Icons.Filled.Campaign, "New broadcast") { nav.push(Screen.Broadcast) } }
            }
            if (typed.length >= 3) item {
                ActionRow(Icons.Filled.Dialpad, when (mode) { Mode.CALL -> "Call $typed"; else -> "Send to $typed" }) { pick(typed) }
            }
            if (!hasPerm && contacts.isEmpty()) item {
                Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Allow contacts access to see the people saved on your phone.", color = wa.sub)
                    TextButton({ permLauncher.launch(Manifest.permission.READ_CONTACTS) }) { Text("Allow contacts") }
                }
            } else if (contacts.isEmpty()) item {
                Text("No saved contacts yet. Tap “New contact” to add one.", color = wa.sub, modifier = Modifier.padding(24.dp))
            }
            if (filtered.isNotEmpty()) item {
                Text("Contacts", color = wa.sub, fontSize = 14.sp, modifier = Modifier.padding(start = 16.dp, top = 12.dp, bottom = 4.dp))
            }
            items(filtered, key = { it.key }) { c ->
                Row(Modifier.fillMaxWidth().clickable { pick(c.number) }.padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Avatar(c.name, 46.dp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text(c.name, fontSize = 17.sp, color = wa.text, fontWeight = FontWeight.Medium)
                        Text(c.number, fontSize = 14.sp, color = wa.sub)
                    }
                }
            }
        }
    }
}

private data class Country(val iso: String, val name: String, val code: String)

private val COUNTRIES = listOf(
    Country("PK", "Pakistan", "+92"), Country("IN", "India", "+91"), Country("BD", "Bangladesh", "+880"),
    Country("US", "United States", "+1"), Country("CA", "Canada", "+1"), Country("GB", "United Kingdom", "+44"),
    Country("AE", "United Arab Emirates", "+971"), Country("SA", "Saudi Arabia", "+966"), Country("QA", "Qatar", "+974"),
    Country("KW", "Kuwait", "+965"), Country("OM", "Oman", "+968"), Country("BH", "Bahrain", "+973"),
    Country("AF", "Afghanistan", "+93"), Country("IR", "Iran", "+98"), Country("TR", "Türkiye", "+90"),
    Country("EG", "Egypt", "+20"), Country("NG", "Nigeria", "+234"), Country("ZA", "South Africa", "+27"),
    Country("KE", "Kenya", "+254"), Country("ID", "Indonesia", "+62"), Country("MY", "Malaysia", "+60"),
    Country("SG", "Singapore", "+65"), Country("PH", "Philippines", "+63"), Country("CN", "China", "+86"),
    Country("JP", "Japan", "+81"), Country("KR", "South Korea", "+82"), Country("AU", "Australia", "+61"),
    Country("NZ", "New Zealand", "+64"), Country("DE", "Germany", "+49"), Country("FR", "France", "+33"),
    Country("IT", "Italy", "+39"), Country("ES", "Spain", "+34"), Country("NL", "Netherlands", "+31"),
    Country("SE", "Sweden", "+46"), Country("RU", "Russia", "+7"), Country("BR", "Brazil", "+55"),
    Country("MX", "Mexico", "+52"), Country("AR", "Argentina", "+54"), Country("CO", "Colombia", "+57"),
    Country("LK", "Sri Lanka", "+94"), Country("NP", "Nepal", "+977")
)

@Composable
fun NewContactScreen(vm: MainViewModel, prefill: String, nav: Nav) {
    val wa = LocalWA.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val simIso = remember { try { ctx.getSystemService(TelephonyManager::class.java).simCountryIso.uppercase() } catch (_: Exception) { "" } }
    val initCountry = remember {
        if (prefill.startsWith("+")) COUNTRIES.filter { prefill.startsWith(it.code) }.maxByOrNull { it.code.length }
        else null
    } ?: COUNTRIES.firstOrNull { it.iso == simIso } ?: COUNTRIES.first()
    var first by remember { mutableStateOf("") }
    var last by remember { mutableStateOf("") }
    var country by remember { mutableStateOf(initCountry) }
    var number by remember {
        mutableStateOf(if (prefill.startsWith("+") && prefill.startsWith(initCountry.code)) prefill.removePrefix(initCountry.code) else prefill.filter { it.isDigit() })
    }
    var menu by remember { mutableStateOf(false) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (ctx.checkSelfPermission(Manifest.permission.WRITE_CONTACTS) != PackageManager.PERMISSION_GRANTED)
            permLauncher.launch(Manifest.permission.WRITE_CONTACTS)
    }

    Column(Modifier.fillMaxSize().background(wa.bg)) {
        SimpleTopBar("New contact", onBack = { nav.pop() })
        Column(Modifier.padding(16.dp).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedTextField(first, { first = it }, label = { Text("First name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(last, { last = it }, label = { Text("Last name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Box {
                OutlinedButton({ menu = true }, Modifier.fillMaxWidth()) { Text("${country.name} (${country.code})") }
                DropdownMenu(menu, { menu = false }, Modifier.heightIn(max = 360.dp)) {
                    COUNTRIES.forEach { c ->
                        DropdownMenuItem(text = { Text("${c.name} (${c.code})") }, onClick = { country = c; menu = false })
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(country.code, {}, readOnly = true, label = { Text("Code") }, singleLine = true, modifier = Modifier.width(96.dp))
                OutlinedTextField(
                    number, { number = it.filter { ch -> ch.isDigit() } }, label = { Text("Phone number") }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.weight(1f)
                )
            }
            Button(
                onClick = {
                    val digits = number.trimStart('0')
                    when {
                        first.isBlank() && last.isBlank() -> Toast.makeText(ctx, "Enter a name", Toast.LENGTH_SHORT).show()
                        digits.length < 5 -> Toast.makeText(ctx, "Enter a valid phone number", Toast.LENGTH_SHORT).show()
                        else -> scope.launch {
                            val full = country.code + digits
                            if (vm.saveContact(first.trim(), last.trim(), full)) {
                                val t = vm.ensure(full)
                                nav.replace(Screen.Chat(t.threadKey))
                            } else Toast.makeText(ctx, "Could not save. Allow contacts permission.", Toast.LENGTH_LONG).show()
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = wa.accent, contentColor = if (wa.dark) wa.onAccent else Color.White)
            ) { Text("Save", fontSize = 16.sp) }
        }
    }
}

@Composable
fun BroadcastScreen(vm: MainViewModel, nav: Nav) {
    val wa = LocalWA.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val contacts by vm.contacts.collectAsState()
    val picked = remember { mutableStateListOf<String>() }
    var name by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().background(wa.bg)) {
        SimpleTopBar("New broadcast", "${picked.size} selected", onBack = { nav.pop() })
        OutlinedTextField(
            name, { name = it }, label = { Text("List name (optional)") }, singleLine = true,
            modifier = Modifier.fillMaxWidth().padding(16.dp)
        )
        LazyColumn(Modifier.weight(1f)) {
            if (contacts.isEmpty()) item { Text("No saved contacts to broadcast to.", color = wa.sub, modifier = Modifier.padding(24.dp)) }
            items(contacts, key = { it.key }) { c ->
                val on = c.number in picked
                Row(
                    Modifier.fillMaxWidth().clickable { if (on) picked.remove(c.number) else picked.add(c.number) }.padding(horizontal = 16.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Avatar(c.name, 42.dp); Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(c.name, color = wa.text, fontSize = 16.sp); Text(c.number, color = wa.sub, fontSize = 13.sp) }
                    Checkbox(on, { if (it) picked.add(c.number) else picked.remove(c.number) })
                }
            }
        }
        Button(
            onClick = {
                if (picked.size < 2) Toast.makeText(ctx, "Select at least 2 contacts", Toast.LENGTH_SHORT).show()
                else scope.launch {
                    val t = vm.createBroadcast(name.ifBlank { "Broadcast (${picked.size})" }, picked.toList())
                    nav.replace(Screen.Chat(t.threadKey))
                }
            },
            modifier = Modifier.fillMaxWidth().padding(16.dp).height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = wa.accent, contentColor = if (wa.dark) wa.onAccent else Color.White)
        ) { Text("Create broadcast list") }
    }
}

@Composable
fun StarredScreen(vm: MainViewModel, nav: Nav) {
    val wa = LocalWA.current
    val starred by vm.starred.collectAsState()
    val cm by vm.contactMap.collectAsState()
    Column(Modifier.fillMaxSize().background(wa.bg)) {
        SimpleTopBar("Starred messages", onBack = { nav.pop() })
        LazyColumn(Modifier.fillMaxSize()) {
            if (starred.isEmpty()) item {
                Text("No starred messages.\nLong-press a message in a chat and tap the star.", color = wa.sub, modifier = Modifier.padding(32.dp), lineHeight = 22.sp)
            }
            items(starred, key = { it.id }) { m ->
                val who = if (m.outgoing) "You" else (cm[m.threadKey]?.name ?: m.address)
                Row(Modifier.fillMaxWidth().clickable { nav.push(Screen.Chat(m.threadKey)) }.padding(16.dp), verticalAlignment = Alignment.Top) {
                    Column(Modifier.weight(1f)) {
                        Text(who, fontWeight = FontWeight.Bold, color = wa.text)
                        Text(m.body, color = wa.text, fontSize = 15.sp)
                        Text("${dayLabel(m.timestamp)}, ${fmtTime(m.timestamp)}", color = wa.sub, fontSize = 12.sp)
                    }
                    IconButton({ vm.star(listOf(m.id), false) }) { Icon(Icons.Filled.Star, "Unstar", tint = wa.accent) }
                }
                HorizontalDivider(color = wa.divider)
            }
        }
    }
}
