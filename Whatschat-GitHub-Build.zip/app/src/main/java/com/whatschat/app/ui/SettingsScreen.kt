package com.whatschat.app.ui

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.whatschat.app.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

@Composable
private fun Header(t: String) {
    Text(t, color = LocalWA.current.accent.takeIf { !LocalWA.current.dark } ?: LocalWA.current.accent, fontWeight = FontWeight.Bold,
        fontSize = 14.sp, modifier = Modifier.padding(start = 20.dp, top = 20.dp, bottom = 4.dp))
}

@Composable
private fun Item(icon: ImageVector, title: String, sub: String? = null, onClick: (() -> Unit)? = null, trailing: @Composable () -> Unit = {}) {
    val wa = LocalWA.current
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = wa.sub)
        Spacer(Modifier.width(20.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontSize = 16.sp, color = wa.text)
            if (sub != null) Text(sub, fontSize = 13.sp, color = wa.sub)
        }
        trailing()
    }
}

@Composable
fun SettingsScreen(vm: MainViewModel, nav: Nav) {
    val wa = LocalWA.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val p by vm.settings.collectAsState()
    var dlg by remember { mutableStateOf("") }
    var photoVer by remember { mutableIntStateOf(0) }
    val photo = remember(photoVer) { loadProfile(ctx) }
    val sims = remember { SmsSender.simNames(ctx) }
    val (isDefault, requestDefault) = rememberDefaultSms()

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch(Dispatchers.IO) {
            ctx.contentResolver.openInputStream(uri)?.use { i -> File(ctx.filesDir, "profile.jpg").outputStream().use { o -> i.copyTo(o) } }
            photoVer++
        }
    }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch(Dispatchers.IO) {
            val s = vm.exportJson()
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(s.toByteArray()) }
            withContext(Dispatchers.Main) { Toast.makeText(ctx, "Backup saved", Toast.LENGTH_SHORT).show() }
        }
    }
    val loader = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch(Dispatchers.IO) {
            val s = ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            val ok = s != null && runCatching { vm.importJson(s) }.isSuccess
            withContext(Dispatchers.Main) { Toast.makeText(ctx, if (ok) "Backup restored" else "Invalid backup file", Toast.LENGTH_SHORT).show() }
        }
    }

    Column(Modifier.fillMaxSize().background(wa.bg)) {
        SimpleTopBar("Settings", onBack = { nav.pop() })
        LazyColumn(Modifier.fillMaxSize()) {
            item {
                Row(Modifier.fillMaxWidth().padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.clickable { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) {
                        Avatar(p.name.ifBlank { "Me" }, 64.dp, photo)
                    }
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text(p.name.ifBlank { "Add your name" }, fontSize = 20.sp, fontWeight = FontWeight.Medium, color = wa.text,
                            modifier = Modifier.clickable { dlg = "name" })
                        Text(p.about, fontSize = 14.sp, color = wa.sub, modifier = Modifier.clickable { dlg = "about" })
                    }
                }
                HorizontalDivider(color = wa.divider)
                Header("SIM & SMS")
                Item(Icons.Filled.SimCard, "Default SIM", if (p.defaultSlot == 0) sims.getOrNull(0) ?: "SIM 1" else sims.getOrNull(1) ?: "SIM 2") { dlg = "sim" }
                Item(
                    Icons.Filled.Sms, "SIM SMS package",
                    if (p.allowance > 0) "${(p.allowance - p.used).coerceAtLeast(0)} remaining of ${p.allowance} this month (${p.used} used)"
                    else "Tap to set your monthly SMS allowance (${p.used} sent this month)"
                ) { dlg = "allowance" }
                Item(Icons.Filled.DoneAll, "Delivery reports", "Show double tick when delivered", trailing = {
                    Switch(p.deliveryReports, { v -> vm.updateSettings { it.copy(deliveryReports = v) } })
                })
                Item(
                    Icons.Filled.Message, "Default SMS app",
                    if (isDefault) "Whatschat is your default SMS app" else "Whatschat is not the default SMS app",
                    trailing = { if (!isDefault) TextButton(requestDefault) { Text("Set") } }
                )
                Header("Chats")
                Item(Icons.Filled.Palette, "Theme", listOf("System default", "Light", "Dark")[p.theme]) { dlg = "theme" }
                Item(Icons.Filled.Wallpaper, "Chat wallpaper") { dlg = "wall" }
                Item(Icons.Filled.FormatSize, "Font size", "${(p.fontScale * 100).toInt()}%") { dlg = "font" }
                Header("Notifications")
                Item(Icons.Filled.Notifications, "Message notifications", trailing = {
                    Switch(p.notifications, { v -> vm.updateSettings { it.copy(notifications = v) } })
                })
                Header("Storage & data")
                Item(Icons.Filled.Backup, "Back up chats", "Save a local JSON file") { saver.launch("whatschat-backup.json") }
                Item(Icons.Filled.Restore, "Restore chats", "Import a Whatschat JSON backup") { loader.launch(arrayOf("application/json", "*/*")) }
                Spacer(Modifier.height(32.dp))
            }
        }
    }

    when (dlg) {
        "name" -> TextDialog("Your name", p.name, onDismiss = { dlg = "" }) { s -> vm.updateSettings { it.copy(name = s) }; dlg = "" }
        "about" -> TextDialog("About", p.about, onDismiss = { dlg = "" }) { s -> vm.updateSettings { it.copy(about = s) }; dlg = "" }
        "allowance" -> TextDialog("Monthly SMS allowance", if (p.allowance > 0) "${p.allowance}" else "", number = true, onDismiss = { dlg = "" }) { s ->
            vm.updateSettings { it.copy(allowance = s.toIntOrNull() ?: 0) }; dlg = ""
        }
        "sim" -> AlertDialog(
            onDismissRequest = { dlg = "" }, title = { Text("Default SIM") },
            text = {
                Column {
                    listOf(sims.getOrNull(0) ?: "SIM 1", sims.getOrNull(1) ?: "SIM 2").forEachIndexed { i, label ->
                        Row(Modifier.fillMaxWidth().clickable { vm.updateSettings { it.copy(defaultSlot = i) }; dlg = "" }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(p.defaultSlot == i, { vm.updateSettings { it.copy(defaultSlot = i) }; dlg = "" })
                            Text(label, color = wa.text)
                        }
                    }
                }
            }, confirmButton = { TextButton({ dlg = "" }) { Text("Close") } }
        )
        "theme" -> AlertDialog(
            onDismissRequest = { dlg = "" }, title = { Text("Theme") },
            text = {
                Column {
                    listOf("System default", "Light", "Dark").forEachIndexed { i, label ->
                        Row(Modifier.fillMaxWidth().clickable { vm.updateSettings { it.copy(theme = i) }; dlg = "" }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(p.theme == i, { vm.updateSettings { it.copy(theme = i) }; dlg = "" })
                            Text(label, color = wa.text)
                        }
                    }
                }
            }, confirmButton = { TextButton({ dlg = "" }) { Text("Close") } }
        )
        "wall" -> AlertDialog(
            onDismissRequest = { dlg = "" }, title = { Text("Chat wallpaper") },
            text = {
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    (if (wa.dark) DarkWalls else LightWalls).forEachIndexed { i, c ->
                        Box(
                            Modifier.size(44.dp).clip(CircleShape).background(Color(c))
                                .border(if (p.wallpaper == i) 3.dp else 1.dp, if (p.wallpaper == i) wa.accent else wa.divider, CircleShape)
                                .clickable { vm.updateSettings { it.copy(wallpaper = i) }; dlg = "" }
                        )
                    }
                }
            }, confirmButton = { TextButton({ dlg = "" }) { Text("Close") } }
        )
        "font" -> AlertDialog(
            onDismissRequest = { dlg = "" }, title = { Text("Font size") },
            text = {
                Column {
                    Slider(p.fontScale, { v -> vm.updateSettings { it.copy(fontScale = v) } }, valueRange = 0.85f..1.3f)
                    Text("${(p.fontScale * 100).toInt()}%", color = wa.sub)
                }
            }, confirmButton = { TextButton({ dlg = "" }) { Text("Done") } }
        )
    }
}
