package com.whatschat.app

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Prefs(
    val name: String = "",
    val about: String = "Hey there! I am using Whatschat.",
    val status: String = "",
    val theme: Int = 0,            // 0 system, 1 light, 2 dark
    val defaultSlot: Int = 0,      // 0 = SIM 1, 1 = SIM 2
    val allowance: Int = 0,        // monthly SMS package size (0 = not set)
    val used: Int = 0,
    val usedMonth: String = "",
    val deliveryReports: Boolean = true,
    val fontScale: Float = 1f,
    val wallpaper: Int = 0,
    val notifications: Boolean = true
)

class SettingsManager(ctx: Context) {
    private val sp = ctx.getSharedPreferences("whatschat", Context.MODE_PRIVATE)
    val state = MutableStateFlow(load())

    private fun month() = SimpleDateFormat("yyyy-MM", Locale.US).format(Date())

    private fun load(): Prefs {
        val d = Prefs()
        var p = Prefs(
            name = sp.getString("name", d.name)!!,
            about = sp.getString("about", d.about)!!,
            status = sp.getString("status", d.status)!!,
            theme = sp.getInt("theme", d.theme),
            defaultSlot = sp.getInt("slot", d.defaultSlot),
            allowance = sp.getInt("allowance", d.allowance),
            used = sp.getInt("used", d.used),
            usedMonth = sp.getString("usedMonth", d.usedMonth)!!,
            deliveryReports = sp.getBoolean("reports", d.deliveryReports),
            fontScale = sp.getFloat("font", d.fontScale),
            wallpaper = sp.getInt("wall", d.wallpaper),
            notifications = sp.getBoolean("notif", d.notifications)
        )
        if (p.usedMonth != month()) p = p.copy(used = 0, usedMonth = month())
        return p
    }

    private fun save(p: Prefs) = sp.edit()
        .putString("name", p.name).putString("about", p.about).putString("status", p.status)
        .putInt("theme", p.theme).putInt("slot", p.defaultSlot).putInt("allowance", p.allowance)
        .putInt("used", p.used).putString("usedMonth", p.usedMonth)
        .putBoolean("reports", p.deliveryReports).putFloat("font", p.fontScale)
        .putInt("wall", p.wallpaper).putBoolean("notif", p.notifications).apply()

    @Synchronized
    fun update(f: (Prefs) -> Prefs) {
        val n = f(state.value)
        state.value = n
        save(n)
    }

    fun addUsed(n: Int) = update {
        val m = month()
        if (it.usedMonth == m) it.copy(used = it.used + n) else it.copy(used = n, usedMonth = m)
    }
}
