# Whatschat (Android, Kotlin, Jetpack Compose)

Offline WhatsApp-style messenger over real SIM SMS and voice calls. No servers, no internet.

## Build
1. Open this folder in Android Studio (Koala 2024.1+ / JDK 17).
2. Let Gradle sync (it downloads the wrapper jar automatically; or run `gradle wrapper`).
3. Run on a real phone with a SIM (emulators can't send real SMS/calls).
4. On first launch allow permissions, then tap "Set as default" to receive incoming SMS in Whatschat.

## Notes
- minSdk 26: adaptive vector icons in `mipmap-anydpi-v26` cover every density.
- SMS only (no MMS). Call history comes from the device call log.
- Sideload build: READ_SMS / READ_CALL_LOG / default-SMS role are restricted on Google Play.
